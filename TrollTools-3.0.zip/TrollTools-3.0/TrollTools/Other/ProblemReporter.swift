//
//  RemoteLog.swift
//  TrollTools
//
//  Created by exerhythm on 27.10.2022.
//

import Foundation

func remLog(_ objs: Any...) {
    for obj in objs {
        let args: [CVarArg] = [ String(describing: obj) ]
        withVaList(args) { RLogv("%@", $0) }
    }
}

//class ProblemReporter {
//    func report(_ str: String) {
//        let task = URLSession.shared.dataTask(with: URL(string: "http://home.sourceloc.net")!)
//        task.
//        task.resume()
//    }
//}
