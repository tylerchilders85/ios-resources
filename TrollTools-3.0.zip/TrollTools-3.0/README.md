# TrollTools
TrollTools - Revolutionizing iOS 15 customisation

https://www.youtube.com/watch?v=7yDOF0a8Q6A 


### Credits
https://github.com/mhdhejazi/Dynamic/blob/master/LICENSE - Apache-2.0

https://github.com/yahoojapan/SwiftyXMLParser - MIT

https://github.com/opa334/TrollStore/blob/main/LICENSE - MIT

https://github.com/SerenaKit/SantanderWrappers

UICache
Copyright: Copyright (c) 2019 CoolStar,
           Modified work Copyright (c) 2020-2022 Procursus Team <team@procurs.us>
           Modified work Copyright (c) 2022 Lars Fröder <opa334@protonmail.com>
License: BSD-4-Clause
