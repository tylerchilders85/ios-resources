#ifndef SHA1_HPP
#define SHA1_HPP

extern "C"
{
#include "sha1.h"
}

#endif
