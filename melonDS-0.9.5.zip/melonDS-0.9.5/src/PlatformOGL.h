#ifndef PLATFORMOGL_H
#define PLATFORMOGL_H

// if you don't wanna use glad for your platform
// add your header here!

#include "frontend/glad/glad.h"

#endif
