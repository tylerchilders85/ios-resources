#pragma once

// Fix glad.h including windows.h
#ifdef _WIN32
#include "../windows_headers.h"
#endif

#include "../../glad/glad.h"
